package biblioteca;

public class Professor extends Usuario {
    private String departamento;


    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public void exibirTipoUsuario(){
        System.out.println("Tipo de usuário: "+getTipoUsuario());
        System.out.println("Departamento: "+departamento);
        System.out.println("Nome do Usuário: "+getNome());
        System.out.println("ID do usuário: "+getId());
    }
    @Override
    public String toString() {
        // Chama o toString() da superclasse (Usuario) e adiciona o atributo 'curso'
        return "Professor " +
                super.toString() + // Isso adiciona "Usuario{nome='...', id='...', tipoUsuario='...'}"
                ", departamento='" + departamento + '\'' +
                '}';
    }
}
