package biblioteca;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Emprestimo {
    private Livro livro;
    private Usuario usuario;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;
    private LocalDate dataDevolucaoReal;
    private LocalDate diasParaDevolucao;
    private boolean disponivel;
    private Usuario emprestadoPara;

    public LocalDate getDiasParaDevolucao() {
        return diasParaDevolucao;
    }

    public void setDiasParaDevolucao(LocalDate diasParaDevolucao) {
        this.diasParaDevolucao = diasParaDevolucao;
    }

    public Emprestimo(Livro livro, Usuario usuario, int diasParaDevolucao) {
        this.livro = livro;
        this.usuario = usuario;
        this.dataEmprestimo = LocalDate.now(); // Data atual do empréstimo
        // Define a data de devolução prevista, por exemplo, 15 dias após o empréstimo
        this.dataDevolucao = this.dataEmprestimo.plusDays(diasParaDevolucao);
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(LocalDate dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public LocalDate getDataDevolução() {
        return dataDevolucao;
    }

    public void setDataDevolução(LocalDate dataDevolução) {
        this.dataDevolucao = dataDevolução;
    }

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public LocalDate getDataDecolucaoReal() {
        return dataDevolucaoReal;
    }

    public void setDataDecolucaoReal(LocalDate dataDecolucaoReal) {
        this.dataDevolucaoReal = dataDecolucaoReal;
    }

    public boolean estaAtrasado() {
        if (dataDevolucaoReal != null) {
            // Se já foi devolvido, verifica se a devolução real foi após a prevista
            return dataDevolucaoReal.isAfter(dataDevolucao);
        } else {
            // Se ainda não foi devolvido, verifica se a data atual é após a prevista
            return LocalDate.now().isAfter(dataDevolucao);
        }
    }

    public long calcularDiasAtraso() {
        if (estaAtrasado()) {
            LocalDate dataBase = (dataDevolucaoReal != null) ? dataDevolucaoReal : LocalDate.now();
            return Period.between(dataDevolucao, dataBase).getDays();
        }
        return 0;
    }

    public void exibirResumoEmprestimo() {
        System.out.println("Livro emprestado: " + livro);
        System.out.println("Usuário que alugou o livro: " + usuario);
        System.out.println("Data do empréstimo: " + dataEmprestimo.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        System.out.println("Data da devolução: " + dataDevolucao.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));

        if (dataDevolucaoReal != null) {
            System.out.println("Data de Devolução Real: " + dataDevolucaoReal.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
            if (estaAtrasado()) {
                System.out.println("STATUS: ATRASADO (" + calcularDiasAtraso() + " dias)");
            } else {
                System.out.println("STATUS: Devolvido no prazo");
            }
        } else {
            System.out.println("STATUS: Em aberto");
            if (estaAtrasado()) {
                System.out.println("ATENÇÃO: Este empréstimo está atrasado!");
            }
        }
        System.out.println("---------------------------");
    }

    @Override // Método para exibir o Emprestimo de forma legível
    public String toString() {
        return "Emprestimo" +
                "livro=" + livro.getTitulo() +
                ", usuario=" + usuario.getNome() +
                ", dataEmprestimo=" + dataEmprestimo +
                ", dataDevolucaoPrevista=" + dataDevolucao +
                ", dataDevolucaoReal=" + (dataDevolucaoReal != null ? dataDevolucaoReal : "N/A");
    }
}

