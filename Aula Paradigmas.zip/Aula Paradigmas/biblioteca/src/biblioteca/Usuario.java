package biblioteca;

public class Usuario {
    private String nome;
    private String id;
    private String tipoUsuario;




    @Override
    public String toString() {
        return "Usuario{" +
                "nome='" + nome + '\'' +
                ", id='" + id + '\'' +
                ", tipoUsuario='" + tipoUsuario + '\'' +
                '}';
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
    public boolean equals(Object o) {
        // Se o objeto for o mesmo na memória, eles são iguais
        if (this == o) return true;
        // Se o objeto for nulo ou de uma classe diferente, não são iguais
        if (o == null || getClass() != o.getClass()) return false;

        // Converte o objeto genérico para Usuario
        Usuario usuario = (Usuario) o;

        // Compara os usuários pelo ID. Se os IDs forem iguais, os usuários são considerados iguais.
        return id != null ? id.equals(usuario.id) : usuario.id == null;
    }

    @Override
    public int hashCode() {

        return id != null ? id.hashCode() : 0;
    }
}
