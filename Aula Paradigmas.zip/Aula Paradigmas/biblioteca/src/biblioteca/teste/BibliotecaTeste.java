package biblioteca.teste;

import biblioteca.Aluno;
import biblioteca.Emprestimo;
import biblioteca.Livro;
import biblioteca.Professor;

import java.time.LocalDate;

public class BibliotecaTeste {
    public static void main(String[] args) {
        Livro l1 = new Livro("Harry Potter e o Cálice de Fogo","JK Rowling","11111");
        l1.exibirInformacoes();
        System.out.println("-----------------------------------------");

        Livro l2 = new Livro("Crepusculo","Stephenie Meyer","5555");
        l2.exibirInformacoes();
        System.out.println("-----------------------------------------");

        Livro l3 = new Livro("Doutor Sono","Stephen King","888888");
        l3.exibirInformacoes();
        System.out.println("-----------------------------------------");

        Aluno a1 = new Aluno();
        a1.setNome("Natasha");
        a1.setCurso("Ciência da Computação");
        a1.setId("1737360");
        a1.setTipoUsuario("Aluno");
        a1.exibirTipoUsuario();

        System.out.println("-----------------------------------------");

        Aluno a2 = new Aluno();
        a2.setNome("Amanda");
        a2.setCurso("Ciência da Computação");
        a2.setId("188899");
        a2.setTipoUsuario("Aluno");
        a2.exibirTipoUsuario();

        System.out.println("-----------------------------------------");

        Professor p1 = new Professor();
        p1.setNome("Ana");
        p1.setDepartamento("Exatas");
        p1.setId("12345");
        p1.setTipoUsuario("Professor");
        p1.exibirTipoUsuario();

        System.out.println("-----------------------------------------");

       Emprestimo registro1 = null;

        boolean sucessoEmprestimo1 = l1.emprestar(a1);

        if(sucessoEmprestimo1){
            // Se o empréstimo do livro foi bem-sucedido
            registro1 = new Emprestimo(l1, a1,15);
            registro1.exibirResumoEmprestimo();
        }
        else{
            System.out.println("Não foi possível realizar e registrar o empréstimo do Livro para o Aluno.");
        }

        System.out.println("-----------------------------------------");

        Emprestimo registro2 = null;
        boolean sucessoEmprestimo2 = l3.emprestar(p1);
        if(sucessoEmprestimo2){
            registro2 = new Emprestimo(l3, p1,20);
            registro2.exibirResumoEmprestimo();
        }
        else{
            System.out.println("Não foi possível realizar e registrar o empréstimo do Livro para o Aluno.");
        }

        System.out.println("**TENTATIVA FALHA DE EMPRESTAR LIVRO JÁ EMPRESTADO**");
        boolean sucessoEmprestimoTentativaFalha = l1.emprestar(a2); // L1 já está emprestado!

        if (sucessoEmprestimoTentativaFalha) {
            // Este bloco NÃO será executado, pois o Livro l1 já estará indisponível.
            // Mas a mensagem "O livro está indisponível" virá do método emprestar do Livro.
            Emprestimo registroEmprestimoFalho = new Emprestimo(l1, a2, 15);
            System.out.println("Um registro de empréstimo que deveria ter falhado foi criado: " + registroEmprestimoFalho);
        } else {
            // Esta mensagem é exibida porque l1.emprestar(a2, 10) retornou false.
            System.out.println("Não foi possível realizar e registrar este empréstimo, pois o livro está indisponível.");
        }

        System.out.println("-----------------------------------------");


        System.out.println("**DEVOLUÇÃO DO LIVRO**");
        boolean sucessoDevolucao = l1.devolver(a1);

        if (sucessoDevolucao) {
            // Se a devolução foi um sucesso, E SE o registro1 EXISTE (não é null)
            if (registro1 != null) {
                System.out.println("\nRegistro do Empréstimo após devolução:");
                registro1.exibirResumoEmprestimo();
            } else {
                System.out.println("Erro: Registro do Empréstimo não encontrado para atualização.");
            }
        } else {
            System.out.println("Não foi possível realizar a devolução do Livro 1.");
        }

    }

    }

