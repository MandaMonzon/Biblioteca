package biblioteca;

import java.time.LocalDate;
import java.util.Objects;

public class Aluno extends Usuario {
    private String curso;



    public void exibirTipoUsuario() {
        System.out.println("Tipo de usuário: " + getTipoUsuario());
        System.out.println("Curso: " + curso);
        System.out.println("Nome do Usuário: " + getNome());
        System.out.println("ID do usuário: " + getId());
    }


    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    @Override
    public String toString() {
        // Chama o toString() da superclasse (Usuario) e adiciona o atributo 'curso'
        return "Aluno" +
                super.toString() + // Isso adiciona "Usuario{nome='...', id='...', tipoUsuario='...'}"
                ", curso='" + curso + '\'' +
                '}';
    }

}
