package biblioteca;

public class Livro {
    private String titulo;
    private String autor;
    private String isbn;
    private boolean disponivel;
    private Usuario emprestadoPara;

    public Livro(String titulo, String autor, String isbn) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.disponivel = true; // Por padrão, todo livro novo está disponível
        this.emprestadoPara = null; // Ninguém o pegou ainda
    }
    public boolean emprestar(Usuario usuario){
        if(this.disponivel){
            this.setDisponivel(false);
            this.emprestadoPara = usuario;
            System.out.println("Livro "+this.titulo+ " emprestado");
            System.out.println("Empréstimo feito com sucesso");
            return true;
        }
        else{
            System.out.println("O livro "+this.titulo+" está indisponível");
            if(emprestadoPara != null){
                System.out.println("Atualmente emprestado para: "+this.emprestadoPara);
            }
        }
        return false;
    }
    public boolean devolver(Usuario usuario) {
        if (!this.disponivel && this.emprestadoPara != null && this.emprestadoPara.equals(usuario)) {
            this.setDisponivel(true);
            System.out.println("Livro '" + this.titulo + "' devolvido por '" + usuario.getNome() + "'.");
            this.emprestadoPara = null;
            return true;
        } else if (this.disponivel) {
            System.out.println("O livro '" + this.titulo + "' já está disponível. Não precisa ser devolvido.");
            return false;
        } else if (this.emprestadoPara != null && !this.emprestadoPara.equals(usuario)) {
            System.out.println("Erro: O livro '" + this.titulo + "' está emprestado para outro usuário (" + this.emprestadoPara.getNome() + ").");
            return false;
        } else {
            System.out.println("Erro: Não foi possível devolver o livro '" + this.titulo + "'.");
            return false;
        }
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Usuario getEmprestadoPara() {
        return emprestadoPara;
    }

    public void setEmprestadoPara(Usuario emprestadoPara) {
        this.emprestadoPara = emprestadoPara;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
    @Override // Boa prática para indicar que você está sobrescrevendo um método
    public String toString() {
        return "Livro{" +
                "titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", isbn='" + isbn + '\'' +
                '}';
    }
    public void exibirInformacoes(){
        System.out.println("Título do livro: "+titulo);
        System.out.println("Nome do autor: "+autor);
        System.out.println("ISBN: "+isbn);
        System.out.println("Disponível: "+disponivel);
    }
}
